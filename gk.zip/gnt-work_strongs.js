
orig_path = './MP/';

var book_index = [ 
	[ 'Matthew', 28, '01mat/', '01 Matthew/', '01Matt' ],
	[ 'Mark', 16, '02mar/', '02 Mark/', '02Mark' ],
	[ 'Luke', 24, '03luk/', '03 Luke/', '03Luke' ],
	[ 'John', 21, '04jhn/', '04 John/', '04John' ],
	[ 'Acts', 28, '05act/', '05 Acts/', '05Acts' ],
	[ 'Romans', 16, '06rom/', '06 Romans', '06Roma' ],
	[ '1 Corinthians', 16, '07co1/', '07 1 Corinthians/', '071Cor' ],
	[ '2 Corinthians', 13, '08co2/', '08 2 Corinthians/', '082Cor' ],
	[ 'Galatians', 6, '09gal/', '09 Galatians/', '09Gala' ],
	[ 'Ephesians', 6, '10eph/', '10 Ephesians/', '10Ephe' ],
	[ 'Philippians', 4, '11phi/', '11 Philippians/', '11Phil' ],
	[ 'Colossians', 4, '12col/', '12 Colossians/', '12Colo' ],
	[ '1 Thessalonians', 5, '13th1/', '13 1 Thessalonians/', '131The' ],
	[ '2 Thessalonians', 3, '14th2/', '14 2 Thessalonians/', '142The' ],
	[ '1 Timothy', 6, '15ti1/', '15 1 Timothy/', '151Tim' ],
	[ '2 Timothy', 4, '16ti2/', '16 2 Timothy/', '161Tim' ],
	[ 'Titus', 3, '17tit/', '17 Titus/', '17Titu/' ],
	[ 'Philemon', 1, '18phi/', '18 Philemon/', '18Phil' ],
	[ 'Hebrews', 13, '19heb/', '19 Hebrews/', '19Hebr' ],
	[ 'James', 5, '20jam/', '20 James/', '20Jame' ],
	[ '1 Peter', 5, '21pe1/', '21 1 Peter/', '21Pete' ],
	[ '2 Peter', 3, '22pe2/', '22 2 Peter/', '22Pete' ], 
	[ '1 John', 5, '23jo1/', '23 1 John', '231Joh' ], 
	[ '2 John', 1, '24jo2/', '24 2 John', '242Joh' ], 
	[ '3 John', 1,  '25jo3/', '25 3 John', '253Joh' ],
	[ 'Jude', 1, '26jud/', '26 Jude', '26Jude' ], 
	[ 'Revelation', 22, '27rev/', '27 Revelation', '27Reve' ]
	];
	

var fonts = [
	'Arial',
	'Times',
	'Courier',
	'Tahoma',
	'Helvetica',
	'Georgia',
	'Freeserif'
	];

var fontsz= [ '10px', '12px', '14px', '16px', '18px', '20px', '22px' ];


var g_accent=null;
var ch = 0;
var audio_path = './mp/';
var last_clicked=null;
var g_fontstyle=true;


function playSoundMain(path, subpath, soundfile ) {
// swfobject.embedSWF("player_mp3_mini.swf", soundfile, "200", "20", "9.0.0", "", {"mp3":"./vocab/"+soundfile}, {"bgcolor":"#085c68"} );
fullpath = path+subpath+soundfile;
 document.getElementById("dummy").innerHTML="<source src=\""+fullpath+"\" type=\"audio/mpeg\"><object class=\"playerpreview\" type=\"application/x-shockwave-flash\" data=\"./player_mp3_mini.swf\"  width=\"0\" height=\"0\" ><param name=\"FlashVars\" value=\""+fullpath+"\"/><embed href=\"./player_mp3_mini.swf\" width=\"0\" height=\"0\" flashvars=\""+fullpath+"\" /></object>";
document.getElementById("dummy").load();
 document.getElementById("dummy").play();
}


function playSound(path, subpath, soundfile ) {
fullpath = path+subpath+soundfile;
 document.getElementById("dummy2").innerHTML="<object data=\""+fullpath+"\" type=\"audio/mpeg\"  width=\"0\"  height=\"0\" title=\""+soundfile+"\"/><param name=\"autostart\" value=\"true\" /><param name=\"hidden\" value=\"false\" /><param name=loop value=false /></object>";
}

function playSoundIE(path, subpath, soundfile ) {


	var fullpath = path+subpath+soundfile;
/*
	var mydoc = document.getElementById("dummy");
	
	mydoc.setAttribute

		var aud = document.createElement('OBJECT');
		aud.setAttribute('class','playerpreview');
		aud.setAttribute('type','0');
		aud.setAttribute('align','top');
		var sourc = document.createElement('SOURCE');
		sourc.setAttribute('src',fullpath);
		sourc.setAttribute('type','audio/mpeg');
		dum.applyElement( aud, 'inside' );
		aud.applyElement( sourc, 'inside' );


	.innerHTML="<source src=\""+fullpath+"\" type=\"audio/mpeg\"><object class=\"playerpreview\" type=\"application/x-shockwave-flash\" data=\"./player_mp3_mini.swf\"  width=\"0\" height=\"0\" ><param name=\"FlashVars\" value=\""+fullpath+"\"/><embed href=\"./player_mp3_mini.swf\" width=\"0\" height=\"0\" flashvars=\""+fullpath+"\" /></object>";
	document.getElementById("dummy").load();
	document.getElementById("dummy").play();

*/
	if( 	   navigator.userAgent.search('MSIE 7') >= 0 
		|| navigator.userAgent.search('MSIE 8') >= 0 
		|| navigator.userAgent.search('MSIE 9') >= 0 
		)
	{
		playSoundMain( path, subpath, soundfile );
		return;

		var dum = document.getElementById("dummy3");
		dum.innerHTML = "";
		var aud = document.createElement('BGSOUND');
		aud.setAttribute('scr', fullpath );
		aud.setAttribute('autostart', true );
		aud.setAttribute('width', '0' );
		aud.setAttribute('loop', '1' );
		//dum.innerHTML = "<bgsound scr=\""+fullpath+"\" autostart=\"true\" width=\"0\" loop=\"0\"></bgsound>";
		dum.applyElement( aud, 'inside' );
	}
	else
	{
		var dum = document.getElementById("dummy3");
		dum.innerHTML = "";
		//dum.innerHTML = "<audio autoplay=\"autoplay\" width=\"0\" align=top><source scr=\""+fullpath+"\" type=\"audio/mpeg\"></audio>";
		var aud = document.createElement('AUDIO');
		aud.setAttribute('autoplay','autoplay');
		aud.setAttribute('width','0');
		aud.setAttribute('align','top');
		var sourc = document.createElement('SOURCE');
		sourc.setAttribute('src',fullpath);
		sourc.setAttribute('type','audio/mpeg');
		dum.applyElement( aud, 'inside' );
		aud.applyElement( sourc, 'inside' );
	}
}

function getCookie(c_name)
{
	if (document.cookie.length>0)
  	{
  		c_start=document.cookie.indexOf(c_name + "=");
  		if (c_start!=-1)
    		{
    			c_start=c_start + c_name.length+1;
    			c_end=document.cookie.indexOf(";",c_start);
    			if (c_end==-1) c_end=document.cookie.length;
    			return unescape(document.cookie.substring(c_start,c_end));
    		}
  	}
	return "";
}

function setCookie(c_name,value,expiredays)
{
	var exdate=new Date();
	exdate.setDate(exdate.getDate()+expiredays);
	document.cookie=c_name+ "=" +escape(value)+
	((expiredays==null) ? "" : ";expires="+exdate.toUTCString());
}



function toggleAccents()
{
	if( g_accent != 1 )
		g_accent = 1;
	else
		g_accent = 0;

	setCookie('accents', g_accent, 365 );

	//alert( g_accent );
}

function toggleVersePerLine()
{
	if( g_verse_per_line != 1 )
		g_verse_per_line = 1;
	else
		g_verse_per_line = 0;

	setCookie('verse_per_line', g_verse_per_line, 365 );

	//alert( g_accent );
}

function displayText( book, chapter)
{

	document.getElementById('book_title').innerHTML = book_index[book][0];

	if( chapter != null && chapter != "" )
		ch = chapter;
	else
		ch = '0';

	g_accent = getCookie( 'accents' );

	g_verse_per_line = getCookie( 'verse_per_line' );

	last_clicked = getCookie( 'last_clicked' );


	document.getElementById('greektext').innerHTML = "";

	var player="";

	if( navigator.userAgent.search("Chrome") >= 0 )
		player = "playSoundMain";
	else if( navigator.userAgent.search("Safari") >= 0 )
		player = "playSoundMain";
	else if( navigator.userAgent.search("MSIE") >= 0 )
		player = "playSoundIE";
	else if( navigator.userAgent.search("Firefox") >= 0 )
		player = "playSound";
	else
		player = "playSound";
		
	if( accent_text[0] == null )
		return;

	var offset=0;
	for( b=0; b < book; b++ )
		offset += book_index[b][1];

	//alert( offset + ch );

	chapnum = (Number(ch)+Number(1));

	if( chapnum < 10 )
		chapnum = '0' + chapnum;

	document.getElementById('chapter').innerHTML='<i onClick="'+ player +'(\'' + orig_path + '\', \'' + book_index[g_last_book][3] + '\', \'' + book_index[g_last_book][4] + chapnum + '.mp3\')">Chapter ' + (Number(ch)+1) + '</i>';

	chp = Number(offset)+Number(ch);

	var grk_text = null;

	if( g_accent == 1 )
	{
		grk_text = accent_text;	
	}
	else
	{
		grk_text = nonaccent_text;
	}

	var ie=0;

	if( navigator.userAgent.search("MSIE") >= 0 )
		ie=1;

	var doc=document.getElementById('greektext');

	doc.innerHTML = "";

	for( i=0; i < grk_text[chp].length; i++ )
	{
	
		{
			if( grk_text[chp][i][2].length > 10 )
			{
				doc.innerHTML += "<b style=\"color: #f04040;\" onClick=\"highlight( '" + book_index[book][0]+" "+ch+":"+grk_text[chp][i][1]+"'); " + player + "('" + audio_path + "', '" + book_index[g_last_book][2] + "', '" + grk_text[chp][i][0] + "');\">"+grk_text[chp][i][1]+"</b>";
				//doc.innerHTML += "<i id=\""+ book_index[book][0]+" "+ch+":"+grk_text[chp][i][1]+"\" > "+grk_text[chp][i][2]+" </i>";
				
				var gtext = grk_text[chp][i][2].split( ' ' );

				var len = gtext.length;
				//alert(len);
				var span = "";

				span += "<span id=\""+ book_index[book][0]+" "+ch+":"+grk_text[chp][i][1]+"\"  >";
				for( x=0; x < len; x++ )
				{
					span += " <i id=\"" + chp + ":" + i + ":" + x + "\" onMouseOver=\"doWord(this,'" + chp + "','" + i + "','" + x + "','" + gtext[x] + "');\">" + gtext[x] + "</i> ";
				}
				span += "</span>";

				doc.innerHTML += span;
			}
			else
			{
				doc.innerHTML += "<b style=\"color: #999999;\"> ["+grk_text[chp][i][1]+" </b>";
				doc.innerHTML += "<i style=\"color: #999999;\"> omitted</i><b style=\"color: #999999;\">] </b>";
			}	
		}

		
		if( g_verse_per_line == 1 )
			document.getElementById('greektext').innerHTML += "<br>";
	}

	highlight( last_clicked );

}

function lookUpStrongs( chp, vers, word )
{
	var sen = nonaccent_text[chp][vers][2];
	var wrds= sen.split(' ');
	var wrd=wrds[word];

	//return nonaccent_text[chp][vers];
	//return strongs[chp][vers];
	//return wrds;
	//return strongs[0][chp];

	for( i=0; i < strongs[chp][vers].length; i++ )
	{
		if( strongs[chp][vers][i][0] == wrd )
			return "\n" + strongs[chp][vers][i] + "\n" + strongs_list[strongs[chp][vers][i][1]];
	}
	return "\n'" + wrd + "'" + " not found"; // in:\n" + strongs[chp][vers];
}

function doWord(val, chap, vers, idx, word)
{
	var str = word + " - ";
	str += lookUpStrongs( chap, vers, idx, word ); 
	//val.setAttribute('title', word );
	val.setAttribute('title', str );
}

function highlight(verseid)
{


	if( last_clicked != null )
	{
		var lv = document.getElementById(last_clicked);
		if( lv != null )
			lv.style.background="#ffffff";
	}
	
	var v = document.getElementById(verseid);
	if( v != null )
	{
		v.style.background="yellow";
		last_clicked=verseid;
		setCookie( 'last_clicked', verseid, 365 );
	}
		
}

function buildSelect()
{
	chap = getCookie( 'chapt' );
	book = getCookie( 'book' );
	fnt = getCookie( 'font' );
	fntz = getCookie( 'fontsize' );

	if( chap == '' || chap == null )
		chap=0;

	if( fnt == '' || fnt == null )
		fnt=0;

	if( fntz == '' || fntz == null )
		fntz=4;

	if( book == '' || book == null )
		book=0;

	var v = document.getElementById('chaps');
	v.innerHTML = "";

	var fn = document.getElementById('fontfam');
	fn.innerHTML = "";

	var fnz = document.getElementById('fontsiz');
	fnz.innerHTML = "";

	var fnst = document.getElementById('cbitalic');
	fnst.checked = (g_fontstyle == 'true') ? true : false;

	var bk = document.getElementById('books');
	bk.innerHTML = "";

	for( b=0; b < book_index.length; b++ )
	{	
		//bk.innerHTML += "<option value='"+b+"' " + ((book == b) ? "selected='yes' " : "") + ">" + book_index[b][0] + "</option>";
		var o = document.createElement('OPTION');
		o.value = b;
		o.text = book_index[b][0];
		if( b == book )
			o.selected = 1;
		bk.add(o);
	}

	for( c=0; c < book_index[book][1]; c++ )
	{
		var e = document.createElement('OPTION');
		e.value = c;
		e.text = "Chapter "+(c+1);
		if( c == chap )
			e.selected = 1;
		v.add(e);

	}

	for( f=0; f < fonts.length; f++ )
	{
		var r = document.createElement('OPTION');
		r.value = f;
		r.text = fonts[f];
		if( f == fnt )
			r.selected = 1;
		fn.add(r);

	}

	for( f=0; f < fontsz.length; f++ )
	{
		var r = document.createElement('OPTION');
		r.value = f;
		r.text = fontsz[f];
		if( f == fntz )
			r.selected = 1;
		fnz.add(r);

	}

	

	ch = chap;

	//alert( chap );
}

var g_last_book="";

function display(val)
{
	var v = document.getElementById('chaps');
	var b = document.getElementById('books');
	var vers = document.getElementById('verse');

	vers.innerHTML = "";
	
	setCookie( 'book', b.value, 365 );
	opt = b.options;
	sel = b.selectedIndex;
	if( sel >= 0 )
	{
		itm = opt.item(sel);
	
		if( itm.value != g_last_book )
		{
			g_last_book = b.options[b.selectedIndex].value;
		
			v.selectedIndex=0;
		
			setCookie( 'chapt', '0', 365 );
			ch = 0;

			v.innerHTML = "";

	
			for( c=0; c < book_index[g_last_book][1]; c++ )
			{
				var e = document.createElement('OPTION');
				e.value = c;
				e.text = "Chapter "+(c+1);
				if( c == Number(ch) )
					e.selected = 1;
				v.add(e);

			}
		}

		else
		{
			//v.selectedIndex=ch;
			ch = v.options[v.selectedIndex].value;
			setCookie( 'chapt', ch, 365 );
			v.innerHTML = "";
			for( c=0; c < book_index[g_last_book][1]; c++ )
			{
				var e = document.createElement('OPTION');
				e.value = c;
				e.text = "Chapter "+(c+1);
				if( c == Number(ch) )
					e.selected = 1;
				v.add(e);

			}
		}

		displayText( g_last_book, ch);	
	}
	
}


function setfont()
{
	//alert(val.options[val.selectedIndex].text);
	//document.getElementById('greektext').style.i. = "i{font-family:'"+val.options[val.selectedIndex].text+",serif'; color:#000000; font-size: 18px;} b{ font-family:'Tahoma'; color:#000000; font-size: 20px;} i:hover{color:#F00000;}";
	var val = document.getElementById('fontfam');
	var fnz = document.getElementById('fontsiz');
	var itl = document.getElementById('cbitalic');

	if(document.all) {  
		document.styleSheets[1]['rules'][0].style.fontSize = fnz.options[fnz.selectedIndex].text;  
		document.styleSheets[1]['rules'][0].style.fontFamily = val.options[val.selectedIndex].text;  
		document.styleSheets[1]['rules'][0].style.fontStyle = ((itl.checked == true) ? "italic" : "normal");  
	}  
	else
	{
		document.styleSheets[1]['cssRules'][0].style.fontSize = fnz.options[fnz.selectedIndex].text;
		document.styleSheets[1]['cssRules'][0].style.fontFamily = val.options[val.selectedIndex].text;
		document.styleSheets[1]['cssRules'][0].style.fontStyle = ((itl.checked == true) ? "italic" : "normal");
	}
	  
	//alert(itl.checked); 

	setCookie('font', val.options[val.selectedIndex].value, 365 );
	setCookie('fontsize', fnz.options[fnz.selectedIndex].value, 365 );
	setCookie('fontstyle', itl.checked, 365 );

	//alert(val.options[val.selectedIndex].text);
	
}



function checkCookies()
{
	g_accent = getCookie( 'accents' );
	g_last_book = getCookie( 'book' );
	ch = getCookie( 'chapt' );
	g_font = getCookie('font');
	g_fontstyle = getCookie('fontstyle');
	g_fontsize = getCookie('fontsize');
}

